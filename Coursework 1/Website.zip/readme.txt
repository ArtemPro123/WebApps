Name: Artem Protasavytsky

Student Number: 1618004

E-mail: ProtasavytskyA@cardiff.ac.uk